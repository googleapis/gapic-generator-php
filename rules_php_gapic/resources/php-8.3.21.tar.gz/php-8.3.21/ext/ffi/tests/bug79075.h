/*
 * Multiline comment
 */
  // whitespace line

#define ignore_this_line 1
  //
#define/* inline */FFI_SCOPE /* multi-
line */ "bug79075" /* end
*/

int printf(const char *format, ...);
